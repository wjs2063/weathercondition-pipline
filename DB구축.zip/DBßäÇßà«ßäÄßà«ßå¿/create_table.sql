create TABLE weather_info (
     city varchar(20),
     sub_city varchar(20),
     TM  VARCHAR(50),
     hour int,
     PTY int,
     REH int,
     RN1 int,
     T1H int,
     UUU int,
     VEC int,
     VVV int,
     WSD int
     
);