#!/usr/bin/env python
# coding: utf-8

import json
import pathlib
import airflow
from urllib import request
import requests
import requests.exceptions as request_exceptions
from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
import datetime as dt
from pathlib import Path
import pandas as pd
import pendulum
import os.path
from airflow.operators.dummy import DummyOperator
import ssl
import pandas as pd
from collections import defaultdict
import requests
import pickle
from pathlib import Path
from datetime import datetime,timedelta
ssl._create_default_https_context = ssl._create_unverified_context
API_KEY="비밀용"

df=pd.read_csv(
    "/opt/airflow/logs/기상청41_단기예보 조회서비스_오픈API활용가이드_격자_위경도(20220103).csv")


x=df[['격자 X','격자 Y','1단계','2단계']]
coordinate=set()
korea=dict()
do=defaultdict(list)
for i in range(len(x)):
    coordinate.add((x.loc[i,'격자 X'],x.loc[i,'격자 Y'],x.loc[i,'1단계'],x.loc[i,'2단계']))
for x,y,one,two in coordinate:
    korea[(x,y)]=(one,two)
    do[one].append((x,y,two))
time=datetime.now()
delta=timedelta(hours=5)
# DAG 생성
dag=DAG(
    dag_id='download_weather_information',
    start_date=time-delta,
    schedule_interval=dt.timedelta(hours=1),
    template_searchpath="/opt/airflow",
    max_active_runs=1,
)

#날씨정보 받아와서 data 저장
def _getting_weather(year:int,month:int,day:int,hour:int,output_path:str,execution_date:str)->dict:
    Path(output_path).mkdir(exist_ok=True)
    time=f"{execution_date}"
    for city in ['대구광역시']:
        for x,y,z in do[city]:
            try:
                url=f"https://apis.data.go.kr/1360000/VilageFcstInfoService_2.0/getUltraSrtNcst?serviceKey={API_KEY}&pageNo=1&numOfRows=1000&dataType=JSON&base_date={year}{month:>02}{day}&base_time={hour:>02}00&nx={x}&ny={y}"
                #print(url)
                # SSL 오류떄문에 verify 없애기
                response = requests.get(url,verify=False)
                data = response.json()
                #print(data['response']['body']['items']['item'])
                db=dict()
                db['city']=city
                db['sub_city']=z
                db['datetime']=f"{year}_{month}_{day}_{hour:>02}"
                db['hour']=hour
                for info in data['response']['body']['items']['item']:
                    db[info['category']]=float(info['obsrValue'])
                #print(db)
                #파일 존재하면 삭제
                if os.path.isfile(f'{output_path}/test{x,y,z}.pkl'):
                    os.remove(f'{output_path}/test{x,y,z}.pkl')
                with open(f'{output_path}/test{x,y,z}.pkl','wb') as f:
                    pickle.dump(db,f)
            except KeyError as k:
                print(k)
            except ConnectionError as c:
                print("Connection Error: ",c)
                
                
    return

get_city_weather_data=PythonOperator(
    task_id="getting_city_weather",
    python_callable=_getting_weather,
    op_kwargs={"year":"{{execution_date.year}}",
               "month":"{{execution_date.month}}",
               "day":"{{execution_date.day}}",
               "hour":"{{execution_date.hour}}",
               "output_path":"/opt/airflow/logs/test",
               "execution_date":"{{execution_date}}"
        },
    dag=dag
    )
'''
city    :      대구광역시,
datetime:      시간( 년 월 일 )     
hour    :      시간 ( 시간 ex 1시)
PTY     :      
REH     :   
RN1     : 
T1H     :  
UUU     :  
VEC     :  
VVV     :  
WSD     : 
'''
def _write_to_postgresql(result):
    with open("/opt/airflow/logs/postgres_query.sql", 'a') as f:
        
        f.write(
            "INSERT INTO weather_info VALUES ("
            f" '{result['city']}','{result['sub_city']}' ,'{result['datetime']}', {result['hour']}, {result['PTY']},{result['REH']},{result['RN1']},"
            f" {result['T1H']} , {result['UUU']}   ,  {result['VEC']},  {result['VVV']},  {result['WSD']}"
            ");\n"
        )
    return


def _fetch_weather_information(input_path, execution_date):
    for city in ['대구광역시']:
        for x,y,z in do[city]:
            with open (f'{input_path}/test{x,y,z}.pkl','rb') as f :
                result=pickle.load(f)
                _write_to_postgresql(result)
    return 
#getting_weather(2022,7,23,22)
write_sql=PythonOperator(
    task_id="write_sql",
    python_callable=_fetch_weather_information,
    op_kwargs={
        "input_path":"/opt/airflow/logs/test",
        "execution_date":"{{execution_date}}"
    },
    dag=dag

)

def _delete_sql():
    if os.path.isfile("/opt/airflow/logs/postgres_query.sql"):
        os.remove("/opt/airflow/logs/postgres_query.sql")
    return

write_to_postgres = PostgresOperator(
    task_id="write_to_postgres",
    postgres_conn_id="my_postgres",
    sql="/logs/postgres_query.sql",
    dag=dag,
)
#with open('/Users/pn_jh/Desktop/DockerProjects/weather/test.pkl','rb') as f:
    #print(pickle.load(f))
delete_sql=PythonOperator(
    task_id="delete_sql",
    python_callable=_delete_sql,
    dag=dag
)


get_city_weather_data>>write_sql>>write_to_postgres>>delete_sql










